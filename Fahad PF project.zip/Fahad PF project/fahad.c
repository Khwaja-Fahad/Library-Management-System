#include<stdio.h>
#include<string.h>
#include<stdlib.h>

struct books{
	char book_name[50];
	char author_name[50];
	char category[50];
	int isbn;
	int total_pages;
	int publication_year;
}b;

struct student{
	char std_name[50];
	char std_class[20];
	char std_reg[20];
	char book_name[50];
	int isbn;

}s;


FILE* fp;



void add_book(){
	
	
	fp = fopen("books.txt","a");
		
	printf("Enter Book Title: ");
	fflush(stdin);
	gets(b.book_name);
	
	
	printf("Enter Author Name: ");
	fflush(stdin);
	gets(b.author_name);
	
	
	printf("Enter Category: ");
	fflush(stdin);
	gets(b.category);
	
	
	printf("Enter Book ISBN : ");
	fflush(stdin);
	scanf("%d",&b.isbn);
	
	
	printf("Enter Number of Book Pages : ");
	fflush(stdin);
	scanf("%d",&b.total_pages);
	
	
	printf("Enter Book Publication Year: ");
	fflush(stdin);
	scanf("%d",&b.publication_year);
	
	fwrite(&b, sizeof(b), 1, fp);
	fclose(fp);
	
	printf("\n Book Added Successfully!! \n");
}


void book_list(){

	printf("\n <== Available Books ==> \n");
	
	fp = fopen("books.txt","r");
	while(fread(&b, sizeof(b), 1, fp) == 1){
		printf("\n Title: %s \n Author: %s \n Category: %s \n ISBN: %d \n Book Pages: %d \n Publication Year: %d \n", b.book_name, b.author_name, b.category, b.isbn, b.publication_year, b.total_pages);
	}
	
	fclose(fp);

}




void del(){
	
	int isbn, found=0;
	
	printf("\n Enter The Book ISBN Number To Remove: ");
	scanf("%d",&isbn);
	
	
	FILE* ft;
	
	fp = fopen("books.txt", "r");
	ft = fopen("temp.txt", "w");
	
	while(fread(&b, sizeof(b), 1, fp) ==1){
		if(isbn==b.isbn){
			found=1;
		}else{
			fwrite(&b, sizeof(b), 1, ft);
		}
	}
	
	if(found==1){
		printf("\n Book is Deleted Successfully!! \n");
	}else{
		printf("\n Record is Not Found!! \n");
	}
	
	fclose(fp);
	fclose(ft);
	
	remove("books.txt");
	rename("temp.txt", "books.txt");
}



void issue_book(){
	int found=0;
	
	printf("\n Enter Book ISBN to Issue Book: ");
	scanf("%d", &s.isbn);
	getchar(); // Consume the newline character

	
	fp = fopen("books.txt","r");
	
	
	while(fread(&b, sizeof(b), 1, fp)==1){
		if(b.isbn == s.isbn){
			strcpy(s.book_name,b.book_name);
			found=1;
			break;
		}
	}
	
	if(found==0){
		printf("\n Book Not Found!! \n");
		printf(" Please Try Again!! \n");
		return;
	}
	
	
	fp = fopen("issue.txt","a");
	
	printf("Enter Student Name: ");
	fflush(stdin);
	gets(s.std_name);
	
	
	printf("Enter Student Class: ");
	fflush(stdin);
	gets(s.std_class);
	
	
	printf("Enter Student Reg# No: ");
	fflush(stdin);
	gets(s.std_reg);
	
	printf("\n Book Issued Successfully!! \n");
	
	fwrite(&s, sizeof(s), 1, fp);
	fclose(fp);
	
	
	
}

void issue_list(){
	
		printf("\n <== All Issued Books ==> \n");
	
	fp = fopen("issue.txt","r");
	while(fread(&s, sizeof(s), 1, fp) == 1){
		printf("\n Student Name: %s \n Student Class: %s \n Student Reg# No: %s \n Book Title: %s \n", s.std_name, s.std_class, s.std_reg, s.book_name);
	}
	
	fclose(fp);

}




int main(){
	int operation;
	printf("\n <== WelCome To Comsats Library ==> \n");
	while(1){
		printf("\n <== Available Options: ==> \n");		
		printf("\n1. Add Book \n");
		printf("2. Books List \n");
		printf("3. Remove Book \n");
		printf("4. Issue Book \n");
		printf("5. Issued Book List \n");
		printf("6. Wifi and Proxy \n");
		printf("0. Exit \n\n");
		
		printf("Enter Your Choice: ");
		scanf("%d",&operation);
		getchar();
		
		switch(operation){
			case 0:
				printf("\n Thank You \n Good Bye \n");
				exit(0);
			case 1:
				add_book();
				break;
			case 2:
				book_list();
				break;
			case 3:
				del();
				break;
			case 4:
				issue_book();
				break;
			case 5:
				issue_list();
				break;
			case 6:
				printf("\n \nSet Proxy : 172.16.100.7 - 3022 \n Password = Comsats2001 \n");
				break;
			default:
				printf("Invalid Choice !! \n\n");
				
		}
//		printf("\n Press Any Key To Continue... \n");
//		getchar();
	}
	return 0;
}
